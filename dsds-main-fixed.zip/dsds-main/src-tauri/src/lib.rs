use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
  tauri::Builder::default()
    .plugin(tauri_plugin_fs::init())
    .plugin(tauri_plugin_shell::init())
    .setup(|app| {
      if cfg!(debug_assertions) {
        app.handle().plugin(
          tauri_plugin_log::Builder::default()
            .level(log::LevelFilter::Info)
            .build(),
        )?;
      }

      // Get the main window and configure webview permissions
      if let Some(window) = app.get_webview_window("main") {
        // Log that we're setting up - permissions are handled by the webview
        log::info!("Main window configured for Sovereign Studio");

        // On Linux/WebKitGTK, media permissions need user interaction
        // The browser will prompt - we've done what we can from Rust side
        let _ = window.set_title("Sovereign Studio - Click Allow for Microphone");
      }

      Ok(())
    })
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}
