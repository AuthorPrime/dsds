# Changelog

## [Unreleased] - 2026-01-11

### Fixed
- **Settings persistence**: Settings now save to localStorage and persist across sessions
- **Audio device detection**: Added proper device enumeration before attempting to capture audio
  - `useVoiceActivityDetection.ts`: Now checks for mediaDevices API availability and enumerates devices before getUserMedia
  - `useGeminiLive.ts`: Added device enumeration check in the session open handler
  - Better error messages when no microphone is found

### Added
- **AI audio capture in recordings**: Recordings now include the AI co-host's voice
  - `useGeminiLive.ts`: Added MediaStreamAudioDestinationNode to capture AI output audio
  - `useGeminiLive.ts`: Exports `aiAudioStream` for use by recording hook
  - `useRecording.ts`: Accepts AI audio stream and mixes it with mic/screen audio
  - `RecordTab.tsx`: Passes AI audio stream to startRecording

- **Audio status indicator**: RecordTab now shows audio device status at bottom of page
  - Green indicator when microphone(s) detected
  - Red indicator with error message when no audio devices found
  - Loading state while checking devices

- **WebkitAudioContext fallback**: Added Safari compatibility fallback for AudioContext

### Changed
- **Improved error handling**: Audio hooks now throw errors instead of silently failing, allowing UI to display meaningful messages

### Known Issues
- **Linux/WebKitGTK microphone permissions**: On Linux, the Tauri webview (WebKitGTK) doesn't show a permission prompt for microphone access. Workaround: test the frontend directly in Firefox at `http://localhost:5173` where permissions work correctly.
- **Browser mode limitations**: File system operations (Publish tab, folder scanning) only work in the desktop app, not in browser mode. This is by design - Tauri's fs plugin requires the native runtime.
- **Whisper transcription**: Currently shows placeholder - WhisperLive integration is on the roadmap.
- **PDF rendering**: Currently shows placeholder - full PDF.js integration is on the roadmap.

### Development Notes
- Created `.env` file template for Gemini API key configuration
- All changes maintain backward compatibility with existing features

---

## Files Modified
- `src/hooks/useVoiceActivityDetection.ts`
- `src/hooks/useGeminiLive.ts`
- `src/hooks/useRecording.ts`
- `src/components/tabs/RecordTab.tsx`
- `src/components/tabs/SettingsTab.tsx`
- `src-tauri/src/lib.rs`
- `.env` (created)
